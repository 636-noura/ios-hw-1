/*
 - - - -
 # السلام عليكم
 ## المتطلبات: اصلح الكودات البرمجية التالية
 
 */

var name = "Ahmad"

 name = "Salem"


var myWeight = 60
var FriendWeight = 80
var height = 159


var weightSum = (myWeight + FriendWeight)



var bmi = myWeight * (height * height)

/*
- - - -
# المطلوب الثاني
قم بتعريف بيانات ل ٣ اشخاص، كل شخص يجب ان يكون لدية المعلومات التالية
  * الاسم
 * الاسم الاخير
 * الايميل
 * رقم الهاتف
 * العمر
 * البلد
 * منطقة السكن
 * باسوورد
 * كويتي ؟
 
 */

//Person 1
var firstName1 = "نورا"
var lastName1 = "حمد"
var email1 = "noura@gmail.com"
var phoneNumber1 = "99732647"
var age1 = 17
var country1 = "الكويت"
var area1 = "الفروانية"
var password = "0000"
var isKuwaiti = true

//Person 2
var firstName2 = "دينا"
var lastName2 = "أنور"
var email2 = "dina@gmail.com"
var phoneNumber2 = "99732647"
var age2 = 18
var country2 = "الكويت"
var area2 = "الفروانية"
var password2 = "0000"
var isKuwaiti2 = true





//Person 3
var firstName3 = "بشاير"
var lastName3 = "علي"
var email3 = "hi@gmail.com"
var phoneNumber3 = "99732647"
var age3 = 17
var country3 = "الكويت"
var area3 = "الفر،انية"
var password3 = "0000"
var isKuwaiti3 = true




/*
- - - -
# المطلوب الثالث
* قم بمقارنة معلومات كل شخص مع الشخص الاخر
 * قارن الاعمار اذا كانت متساوية ام لا
 * قارن منطقة السكن اذا كانت متساوية ام لا
 * قارن اذا عمر الاشخاص اكبر من ١٨
 * قارن اذا عمر الاشخاص اصغر من ١٨
 * قارن اذا عمر الاشخاص يساوي  ١٧
 * قارن اذا عمر الاشخاص لا يساوي  ١٧

 
 */
age1 == age2
area1 == area3
age3 > 18
age2 >= 18
age1 > 18
age1 < 18
age2 < 18
age3 < 18
age2 == 17
age3 == 17
age1 == 17
age2 != 17
age3 != 17 

